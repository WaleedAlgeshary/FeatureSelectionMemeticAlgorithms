/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jmetal.metaheuristics.SI;

import java.io.IOException;
import java.util.HashMap;
import jmetal.core.Algorithm;
import jmetal.core.Operator;
import jmetal.core.Problem;
import jmetal.core.SolutionSet;
import jmetal.operators.crossover.CrossoverFactory;
import jmetal.operators.mutation.MutationFactory;
import jmetal.problems.Golinski;
import jmetal.util.JMException;

/**
 *
 * @author tallison
 */
public class Nova_main {
     public static void main(String [] args) throws 
                                  JMException, 
                                  SecurityException, 
                                  IOException, 
                                  ClassNotFoundException {
    Problem   problem   ; // The problem to solve
    Algorithm algorithm ; // The algorithm to use
    Operator  crossover ; // Crossover operator
    Operator  mutation  ; // Mutation operator
    Operator  selection ; // Selection operator
    
    HashMap  parameters ; // Operator parameters
 
    problem = new Golinski("Real");
    algorithm = new Nova(problem);
    
    algorithm.setInputParameter("populationSize", 1000);
    algorithm.setInputParameter("maxEvaluations", 50000);
    
    parameters = new HashMap() ;
    parameters.put("probability", 0.95);
    crossover = CrossoverFactory.getCrossoverOperator("SBXCrossover", parameters);
    
    parameters = new HashMap() ;
    parameters.put("probability", 0.2);
    mutation = MutationFactory.getMutationOperator("PolynomialMutation", parameters);                    
    
    algorithm.addOperator("crossover",crossover);
    algorithm.addOperator("mutation",mutation);
    
    SolutionSet population = algorithm.execute();
    population.printVariablesToFile("VAR");
    population.printObjectivesToFile("FUN");
   }
}
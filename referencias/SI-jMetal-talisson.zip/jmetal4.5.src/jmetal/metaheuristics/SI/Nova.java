/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jmetal.metaheuristics.SI;

import java.util.Random;
import jmetal.core.Algorithm;
import jmetal.core.Operator;
import jmetal.core.Problem;
import jmetal.core.Solution;
import jmetal.core.SolutionSet;
import jmetal.util.Distance;
import jmetal.util.JMException;
import jmetal.util.Ranking;
import jmetal.util.comparators.CrowdingComparator;

/**
 *
 * @author tallison
 */
public class Nova extends Algorithm{

    public Nova(Problem problem) {
        super(problem);
    }

    @Override
    public SolutionSet execute() throws JMException, ClassNotFoundException {
        int popSize;
        int maxIt;
        int it = 0;
        
        SolutionSet pop = null;
        SolutionSet newGen = null;
        
        Operator crossover;
        Operator mutation;
        
        popSize = ((Integer) getInputParameter("populationSize"));
        maxIt = ((Integer) getInputParameter("maxEvaluations"));
        
        pop = new SolutionSet(popSize);
        
        crossover = operators_.get("crossover");
        mutation = operators_.get("mutation");
        
        Solution sol;
        for (int i = 0; i < popSize; i++) {
            sol = new Solution(problem_);
            problem_.evaluate(sol);
            problem_.evaluateConstraints(sol);
            it++;
            pop.add(sol);
        }
        
        SolutionSet front1 = null;
        SolutionSet front2 = null;
        Ranking ranking = new Ranking(pop);
        Random rand = new Random();
        
        front1 = ranking.getSubfront(0);
        front2 = ranking.getSubfront(0);
        
        while(it < maxIt){
            newGen = new SolutionSet(popSize);
            Solution[] par = new Solution[2];
            
            for (int j = 0; j < popSize/2; j++){
                par[0] = front1.get(0);
                par[1] = front1.get(0);
                
                Solution[] newInd = (Solution[]) crossover.execute(par);
                if(rand.nextGaussian() > 0.8)
                    mutation.execute(newInd[0]);
                if(rand.nextGaussian() < 0.2)
                    mutation.execute(newInd[0]);
                
                problem_.evaluate(newInd[0]);
                problem_.evaluateConstraints(newInd[0]);
                problem_.evaluate(newInd[1]);
                problem_.evaluateConstraints(newInd[1]);
                
                newGen.add(newInd[0]);
                newGen.add(newInd[1]);
                it+=2;
            }
        }
        
        Distance distance = new Distance();
        SolutionSet union = ((SolutionSet) pop).union(newGen);
        
        int remain = popSize;
        int index = 0;
        ranking = new Ranking(union);
        SolutionSet front = ranking.getSubfront(0);
        pop.clear();
        
        while ((remain > 0) && (remain >= front.size())) {
        //Assign crowding distance to individuals
        distance.crowdingDistanceAssignment(front, problem_.getNumberOfObjectives());
        //Add the individuals of this front
        for (int k = 0; k < front.size(); k++) {
          pop.add(front.get(k));
        } // for

        //Decrement remain
        remain = remain - front.size();

        //Obtain the next front
        index++;
        if (remain > 0) {
          front = ranking.getSubfront(index);
        } // if        
        } // while

        // Remain is less than front(index).size, insert only the best one
        if (remain > 0) {  // front contains individuals to insert                        
          distance.crowdingDistanceAssignment(front, problem_.getNumberOfObjectives());
          front.sort(new CrowdingComparator());
          for (int k = 0; k < remain; k++) {
            pop.add(front.get(k));
          } // for

          remain = 0;
        }
        
        /*distance.crowdingDistanceAssignment(front, problem_.getNumberOfObjectives());
        front.sort(new CrowdingComparator());
        for (int k = 0; k < popSize; k++) {
          pop.add(front.get(k));
        }*/
        
        // Return as output parameter the required evaluations
        setOutputParameter("evaluations", it);

        // Return the first non-dominated front
        Ranking rank = new Ranking(pop);
        rank.getSubfront(0).printFeasibleFUN("FUN_NSGAII") ;

        return ranking.getSubfront(0);
    }
    
}
